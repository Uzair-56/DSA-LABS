//#include<iostream>
//#include<string>
//using namespace std;
//
//template<typename T>
//void printarray(T arr[], int size = 5)
//{
//    for (int i = 0; i < size; i++)
//    {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
//
//template<typename T>
//void selectionsort(T arr[], int size = 5)
//{
//    for (int i = 0; i < size - 1; i++)
//    {
//        int smallsub = i;
//
//        for (int j = i + 1; j < size; j++)
//        {
//            if (arr[j] < arr[smallsub])
//            {
//                smallsub = j;
//            }
//        }
//
//        if (smallsub != i)
//        {
//            T temp = arr[i];
//            arr[i] = arr[smallsub];
//            arr[smallsub] = temp;
//        }
//    }
//}
//
//int main()
//{
//    int intarray[5] = { 64,25,12,22,11 };
//    cout << "\nOriginal integer array: ";
//    printarray(intarray, 5);
//    selectionsort(intarray, 5);
//    cout << "Sorted integer array: ";
//    printarray(intarray, 5);
//
//    string stringArray[4] = { "apple", "orange", "banana", "grape" };
//    cout << "\nOriginal string array: ";
//    printarray(stringArray, 4);
//    selectionsort(stringArray, 4);
//    cout << "Sorted string array: ";
//    printarray(stringArray, 4);
//
//    return 0;
//}
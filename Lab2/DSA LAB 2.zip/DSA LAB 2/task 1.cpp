#include<iostream>
using namespace std;
class shape
{
	virtual void area() = 0;

};
class circle:public shape
{
private:
	float radius;
public:
	circle(float r)
	{
		radius = r;
	}
	void area()
	{
		cout << "Area is:" << 3.14 * radius * radius;
	}
};
class rectangle :public shape
{
private:
	int length;
	int width;
public:
	rectangle(int l, int w)
	{
		length = l;
		width = w;
	}
	void area()
	{
		cout << "Area is:" << length * width;
	}
};
int main()
{
	int tempradius;
	cout << "\nEnter the value of radius:";
	cin >> tempradius;
	circle c(tempradius);
	c.area();

	int templength;
	cout << "\nEnter the value of length:";
	cin >> templength;
	int tempwidth;
	cout << "Enter the value of width:";
	cin >> tempwidth;
	rectangle r(templength,tempwidth);
	r.area();

	return 0;
}
#include<iostream>
using namespace std;

class item
{
public:
	virtual void display() = 0;
};

class Book :public item
{
private:
	string title;
	string author;
	int pages;

public:

	Book() 
	{

	}   

	Book(string t, string a, int pg)
	{
		title = t;
		author = a;
		pages = pg;
	}

	string getTitle()
	{
		return title;
	}

	int getPages()
	{
		return pages;
	}

	void display()
	{
		cout << "Book:" << title << "\nAuthor: " << author << "\nPages: " << pages << endl;
	}
};

class Newspaper : public item
{
private:
	string name;
	string date;
	string edition;

public:

	Newspaper() 
	{

	}

	Newspaper(string n, string d, string e)
	{
		name = n;
		date = d;
		edition = e;
	}

	string getName()
	{
		return name;
	}

	string getEdition()
	{
		return edition;
	}

	void display()
	{
		cout << "Newspaper: " << name << "\nDate: " << date << "\nEdition: " << edition << endl;
	}
};

template <class T>
int linearSearchBook(T arr[], int size, string key)
{
	for (int i = 0; i < size; i++)
	{
		if (arr[i].getTitle() == key)
		{
			return i;
		}
	}
	return -1;
}

template <class T>
int linearSearchNewspaper(T arr[], int size, string key)
{
	for (int i = 0; i < size; i++)
	{
		if (arr[i].getName() == key)
		{
			return i;
		}
	}
	return -1;
}

class Library
{
private:

	Book books[10];
	Newspaper newspapers[10];

	int bookCount = 0;
	int newspaperCount = 0;

public:

	void addBook(Book b)
	{
		books[bookCount++] = b;
	}

	void addNewspaper(Newspaper n)
	{
		newspapers[newspaperCount++] = n;
	}

	void displayCollection()
	{
		cout << "\nBooks:\n";

		for (int i = 0; i < bookCount; i++)
		{
			books[i].display();
		}

		cout << "\nNewspapers:\n";

		for (int i = 0; i < newspaperCount; i++)
		{
			newspapers[i].display();
		}
	}

	void sortBooksByPages()
	{
		for (int i = 0; i < bookCount - 1; i++)
		{
			for (int j = i + 1; j < bookCount; j++)
			{
				if (books[i].getPages() > books[j].getPages())
				{
					Book temp = books[i];
					books[i] = books[j];
					books[j] = temp;
				}
			}
		}
	}

	void sortNewspapersByEdition()
	{
		for (int i = 0; i < newspaperCount - 1; i++)
		{
			for (int j = i + 1; j < newspaperCount; j++)
			{
				if (newspapers[i].getEdition() > newspapers[j].getEdition())
				{
					Newspaper temp = newspapers[i];
					newspapers[i] = newspapers[j];
					newspapers[j] = temp;
				}
			}
		}
	}

	Book* searchBookByTitle(string title)
	{
		int index = linearSearchBook(books, bookCount, title);

		if (index != -1)
			return &books[index];

		return NULL;
	}

	Newspaper* searchNewspaperByName(string name)
	{
		int index = linearSearchNewspaper(newspapers, newspaperCount, name);

		if (index != -1)
			return &newspapers[index];

		return NULL;
	}
};

int main()
{
	// Create book objects
	Book book1("The Catcher in the Rye", "J.D. Salinger", 277);
	Book book2("To Kill a Mockingbird", "Harper Lee", 324);

	// Create newspaper objects
	Newspaper newspaper1("Washington Post", "2024-10-13", "Morning Edition");
	Newspaper newspaper2("The Times", "2024-10-12", "Weekend Edition");

	// Create library object
	Library library;

	// Add books and newspapers
	library.addBook(book1);
	library.addBook(book2);
	library.addNewspaper(newspaper1);
	library.addNewspaper(newspaper2);

	// Display collection
	cout << "Before Sorting:\n";
	library.displayCollection();

	// Sorting
	library.sortBooksByPages();
	library.sortNewspapersByEdition();

	cout << "\nAfter Sorting:\n";
	library.displayCollection();

	// Search book
	Book* foundBook = library.searchBookByTitle("The Catcher in the Rye");

	if (foundBook)
	{
		cout << "\nFound Book:\n";
		foundBook->display();
	}
	else
	{
		cout << "\nBook not found.\n";
	}

	// Search newspaper
	Newspaper* foundNewspaper = library.searchNewspaperByName("The Times");

	if (foundNewspaper)
	{
		cout << "\nFound Newspaper:\n";
		foundNewspaper->display();
	}
	else
	{
		cout << "\nNewspaper not found.\n";
	}

	return 0;
}
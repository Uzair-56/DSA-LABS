#include<iostream>
using namespace std;

class Employee
{
	virtual void calculatesalary() = 0;
};
class Fulltimeemployee :public Employee
{
private:
	int fixedsalary;
public:
	Fulltimeemployee(int fs)
	{
		fixedsalary = fs;
	}
	void calculatesalary()
	{
		cout << "salary of Fulltimeemployee:" << fixedsalary;
	}
};
class parttimeemployee :public Employee
{
private:
	int hourswork;
	int hourlyrate;
public:
	parttimeemployee(int hw, int hr)
	{
		hourswork = hw;
		hourlyrate = hr;
	}
	void calculatesalary()
	{
		cout << "\nSalary of parttimeemployee:" << hourswork * hourlyrate;
     }
};
int main()
{
	Fulltimeemployee f(1200);
	f.calculatesalary();
	parttimeemployee p(5, 200);
	p.calculatesalary();
}
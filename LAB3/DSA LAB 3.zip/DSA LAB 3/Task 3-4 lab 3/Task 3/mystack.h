#pragma once
#pragma once
#include "AbstractStack.h"
#include <iostream>
using namespace std;

template<typename T>
class mystack : public AbstractStack<T>
{
public:
    mystack(int s);
    ~mystack();
    void push(T value);
    T pop();
    T top();
    bool isEmpty();
    bool isFull();
    void display();
};

template<typename T>
mystack<T>::mystack(int s) : AbstractStack<T>(s) {}

template<typename T>
mystack<T>::~mystack() {}

template<typename T>
bool mystack<T>::isEmpty()
{
    return this->currentsize == 0;
}

template<typename T>
bool mystack<T>::isFull()
{
    return this->currentsize == this->maxsize;
}

template<typename T>
void mystack<T>::push(T value)
{
    if (!isFull())
    {
        this->arr[this->currentsize] = value;
        this->currentsize++;
    }
    else
        cout << "Parking is Full!\n";
}

template<typename T>
T mystack<T>::pop()
{
    if (isEmpty())
    {
        cout << "Parking is Empty!\n";
        return T();
    }
    this->currentsize--;
    return this->arr[this->currentsize];
}

template<typename T>
T mystack<T>::top()
{
    if (isEmpty())
    {
        cout << "Parking is Empty!\n";
        return T();
    }
    return this->arr[this->currentsize - 1];
}

template<typename T>
void mystack<T>::display()
{
    if (isEmpty())
    {
        cout << "Parking is Empty!\n";
        return;
    }
    cout << "Cars in Parking:\n";
    for (int i = 0; i < this->currentsize; i++)
        cout << i + 1 << ". Car Number: " << this->arr[i] << endl;
    cout << "Total cars: " << this->currentsize << endl;
}
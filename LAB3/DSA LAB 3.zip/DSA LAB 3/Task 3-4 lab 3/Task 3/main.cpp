#include <iostream>
#include "mystack.h"
using namespace std;

int main()
{
    mystack<int> parking(8);  // Main parking stack
    mystack<int> temp(8);     // Temporary stack for removing middle cars
    int choice, carNum;

    do
    {
        cout << "\n---- Parking Lot Menu ----\n";
        cout << "1. Park a Car\n";
        cout << "2. Remove a Car\n";
        cout << "3. View All Cars\n";
        cout << "4. Search a Car\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1: // Park a car
            cout << "Enter Car Number to Park: ";
            cin >> carNum;
            parking.push(carNum);
            break;

        case 2: // Remove a car by number
            if (parking.isEmpty())
            {
                cout << "Parking is Empty!\n";
                break;
            }

            cout << "Enter Car Number to Remove: ";
            cin >> carNum;

            bool found;
            found = false;

            while (!parking.isEmpty())
            {
                int topCar = parking.top();
                if (topCar == carNum)
                {
                    parking.pop(); // Remove the desired car
                    found = true;
                    break;
                }
                else
                    temp.push(parking.pop()); // Temporarily remove top cars
            }

            while (!temp.isEmpty())
                parking.push(temp.pop()); // Restore cars

            if (found)
                cout << "Car " << carNum << " removed successfully.\n";
            else
                cout << "Car " << carNum << " not found in parking.\n";
            break;

        case 3: // Display all cars
            parking.display();
            break;

        case 4: // Search a car
            if (parking.isEmpty())
            {
                cout << "Parking is Empty!\n";
                break;
            }
            cout << "Enter Car Number to Search: ";
            cin >> carNum;
            found = false;

            while (!parking.isEmpty())
            {
                int topCar = parking.top();
                if (topCar == carNum)
                    found = true;
                temp.push(parking.pop());
            }

            while (!temp.isEmpty())
                parking.push(temp.pop());

            if (found)
                cout << "Car " << carNum << " is in parking.\n";
            else
                cout << "Car " << carNum << " is NOT in parking.\n";
            break;

        case 5:
            cout << "Exiting Parking System.\n";
            break;

        default:
            cout << "Invalid Choice!\n";
        }

    } while (choice != 5);

    return 0;
}
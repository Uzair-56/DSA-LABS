#include<iostream>
#include<string>
using namespace std;

#include "mystack.h"

int main()
{
    string text = "";

    mystack<string> undoStack(100);
    mystack<string> redoStack(100);

    int choice;
    char ch;

    do
    {
        cout << "\n1.Type Character\n2.Delete Character\n3.Undo\n4.Redo\n5.Show Text\n6.Exit\n";
        cin >> choice;

        switch (choice)
        {
        case 1: // TYPE
            cout << "Enter character: ";
            cin >> ch;

            undoStack.push(text); // save current state
            text += ch;

            // clear redo
            while (!redoStack.isEmpty())
                redoStack.pop();

            break;

        case 2: // DELETE
            if (text.empty())
            {
                cout << "Nothing to delete\n";
                break;
            }

            undoStack.push(text);
            text.pop_back();

            while (!redoStack.isEmpty())
                redoStack.pop();

            break;

        case 3: // UNDO
            if (undoStack.isEmpty())
            {
                cout << "Nothing to undo\n";
                break;
            }

            redoStack.push(text);
            text = undoStack.pop();

            break;

        case 4: // REDO
            if (redoStack.isEmpty())
            {
                cout << "Nothing to redo\n";
                break;
            }

            undoStack.push(text);
            text = redoStack.pop();

            break;

        case 5: // DISPLAY
            cout << "Text: " << text << endl;
            break;
        }

    } while (choice != 6);

    return 0;
}
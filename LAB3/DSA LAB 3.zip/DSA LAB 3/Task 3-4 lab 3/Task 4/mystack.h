#pragma once
#include<iostream>
using namespace std;
#include "AbstractStack.h"

template<typename T>
class mystack : public AbstractStack<T>
{
public:
    mystack(int s);
    void push(T value);
    T pop();
    T top();
    bool isEmpty();
    bool isFull();
};

template<typename T>
mystack<T>::mystack(int s) : AbstractStack<T>(s) {}

template<typename T>
void mystack<T>::push(T value)
{
    if (!isFull())
    {
        this->arr[this->currentsize] = value;
        this->currentsize++;
    }
}

template<typename T>
T mystack<T>::pop()
{
    if (isEmpty())
        return T();

    this->currentsize--;
    return this->arr[this->currentsize];
}

template<typename T>
T mystack<T>::top()
{
    return this->arr[this->currentsize - 1];
}

template<typename T>
bool mystack<T>::isEmpty()
{
    return this->currentsize == 0;
}

template<typename T>
bool mystack<T>::isFull()
{
    return this->currentsize == this->maxsize;
}
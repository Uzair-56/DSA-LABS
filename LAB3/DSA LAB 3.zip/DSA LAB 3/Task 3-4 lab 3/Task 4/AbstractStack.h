#pragma once

template<typename T>
class AbstractStack
{
protected:
    T* arr;
    int maxsize;
    int currentsize = 0;

public:
    AbstractStack(int s);
    ~AbstractStack();

    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() = 0;
    virtual bool isEmpty() = 0;
    virtual bool isFull() = 0;
};

template<typename T>
AbstractStack<T>::AbstractStack(int s)
{
    maxsize = s;
    currentsize = 0;
    arr = new T[maxsize];
}

template<typename T>
AbstractStack<T>::~AbstractStack()
{
    delete[] arr;
}
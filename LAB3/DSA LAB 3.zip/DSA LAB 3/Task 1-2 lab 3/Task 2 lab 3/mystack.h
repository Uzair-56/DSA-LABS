#pragma once
#include"AbstractStack.h"
#include<iostream>
using namespace std;
template<typename T>
class mystack :public AbstractStack<T>
{
private:
	T* minArr;
public:
	mystack(int s);
	~mystack();
     void push(T value);
	 T pop();
	 T top();
     bool isEmpty();
	 bool isFull();
	 void display();

	 T getMin() const;
};

template<typename T>
mystack<T>::mystack(int s) :AbstractStack<T>(s)
{
	minArr = new T[s]; 
}

template<typename T>
mystack<T>::~mystack()
{
	delete[] minArr;
}

template<typename T>
bool mystack<T>::isEmpty()
{
	return this->currentsize == 0;
}

template<typename T>
bool mystack<T>::isFull()
{
	return this->currentsize == this->maxsize;
}

template<typename T>
void mystack<T>::push(T value)
{
	if (!isFull())
	{
		this->arr[this->currentsize] = value;

		if (this->currentsize == 0)
		{
			minArr[this->currentsize] = value;
		}
		else
		{
			if (value < minArr[this->currentsize - 1])
				minArr[this->currentsize] = value;
			else
				minArr[this->currentsize] = minArr[this->currentsize - 1];
		}

		this->currentsize++;
	}
	else
	{
		cout << "Array is Full";
	}
}
template<typename T>
T mystack<T>::getMin() const
{
	if (this->currentsize == 0)
	{
		cout << "Stack Empty";
		return T();
	}
	return minArr[this->currentsize - 1];
}
template<typename T>
T mystack<T>::pop()
{
	if (isEmpty())
	{
		cout << "Array is Empty.";
		return T();
	}

	else
	{
		this->currentsize--;
		return this->arr[this->currentsize];
	}
}

template<typename T>
T mystack<T>::top()
{
	if (isEmpty())
	{
		cout << "Array is Empty.";
		return T();
	}
	else
	{
		return this->arr[this->currentsize - 1];
	}
}

template<typename T>
void mystack<T>::display()
{
	cout << "Maximum Size of Array:" <<this->maxsize;
	cout << "\nCurrent Size of Array:" << this->currentsize;
	cout << endl;

	for (int i = 0; i < this->currentsize; i++)
	{
		cout << i << "." << this->arr[i]<<endl;
	}
}



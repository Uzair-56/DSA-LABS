#include<iostream>
using namespace std;
#include "mystack.h"

int main()
{
	mystack<int> obj(4);

	obj.push(3);
	obj.push(5);
	obj.push(-4);

	cout << "/----Display before pop:/----\n";
	obj.display();

	cout << "Top value: " << obj.top() << endl;

	obj.pop();

	cout << "/----Display after pop:/----\n";
	obj.display();

	cout << "Minimum value: " << obj.getMin() << endl;
}
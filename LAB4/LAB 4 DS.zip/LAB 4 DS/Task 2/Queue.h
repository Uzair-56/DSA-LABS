#include <iostream>
using namespace std;

template<class T>
class Stack
{
protected:

    T* arr;
    int currentSize;
    int maxSize;

public:
    virtual void push(T v) = 0;
    virtual T pop() = 0;

    virtual bool isEmpty() = 0;
    virtual bool isFull() = 0;

    virtual T top() = 0;

    Stack(int size);
    ~Stack();

};

template<class T>
Stack<T>::Stack(int size)
{
    maxSize = size;
    currentSize = 0;
    arr = new T[size];
}

template<class T>
Stack<T>::~Stack()
{
    delete[]arr;
}
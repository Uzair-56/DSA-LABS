
#include "Queue.h"

template<class T>
class myStack :public Stack<T> 
{

public:
    void push(T v);

    myStack(int);
    void display();
    T pop();
    bool isEmpty();
    bool isFull();

    T top();

};

template<class T>
T myStack<T>::top() 
{
    if (isEmpty())
    {
        cout << "Stack is Empty, returning JUNK zero" << endl;
        return 0;
    }
    else
        return Stack<T>::arr[this->currentSize - 1];
}







template<class T>
bool myStack<T>::isFull() 
{
    return (this->currentSize == this->maxSize);
}






template<class T>
bool myStack<T>::isEmpty()  
{
    return (this->currentSize == 0);
}

template<class T>
T myStack<T>::pop() 
{
    if (isEmpty())
    {
        cout << "Stack is Empty, returning JUNK zero" << endl;
        return 0;
    }
    else
        return Stack<T>::arr[--Stack<T>::currentSize];
}

template<class T>   
myStack<T>::myStack(int s) :Stack<T>(s)
{

}

template<class T> 
void myStack<T>::push(T v)
{
    if (!isFull())
    {
        this->arr[Stack<T>::currentSize] = v;
        this->currentSize++;
    }

    else
        cout << "Stack is full" << endl;

}

template<class T>
void myStack<T>::display()      
{
    cout << "Max Size = " << this->maxSize << endl;
    cout << "\nCurrent Size = " << Stack<T>::currentSize << endl;

    for (int i = 0; i < Stack<T>::currentSize; i++)
        cout << i << ". " << this->arr[i] << endl;
}
#include "myQueue.h"

int main()
{
    int size;
    cout << "Enter size of stack";
    cin >> size;
    myStack<int> obj(size);

   

    int value;
    cout << "Enter values that are enqueued:";
    for (int i = 0; i < size; i++)
    {
        cin >> value;
        obj.push(value);

    }
   
   
    cout << "\nTop Value: " << obj.top() << endl;
    obj.display();


    cout << "\\nDequeued using Stacks:";
    myStack<int> s1(size);

    if (s1.isEmpty())
    {
        while (!obj.isEmpty())
        {
            s1.push(obj.top());
                obj.pop();
        }
    }
    cout << "\n----------------------";
    cout << "\nDequeued top:" << s1.top();
    s1.pop();
    s1.display();

    return 0;
}


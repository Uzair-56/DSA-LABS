#include "myQueue.h"

int main()
{
    int size;
    cout << "Enter size of stack";
    cin >> size;
    myQueue<int> obj(size);

    int value;
    cout << "Enter values that are enqueued:";
    for (int i = 0; i < size; i++)
    {                                                    //Enter user values:
        cin >> value;
        obj.enqueue(value);

    }

    //cout << "\nTop Value: " << obj.peek() << endl;    
   // obj.display();

    int k;
    cout << "\nEnter the limit of k:";
    cin >> k;                                          // How many values you should reverse;
    int n = size;                                      // total value = size;
   
    cout << "\nDequeued value upto k:";
    myQueue<int> s1(size);


    if (s1.isEmpty())                                 //put k value into another queueu;
    {
        for(int i=0;i<k;i++)
        {
            s1.enqueue(obj.peek());                  //peek value push to another queue which = k;
            obj.dequeue();                           //remove these values from old queue; 
        }
    }

    s1.display();                                  // new queue values displayed;

    while (!s1.isEmpty())                          // push back to old array using stack; push top value;
    {                                            
        obj.enqueue(s1.top());
          s1.pop();                                // remove from new queue;
    }

   // obj.display();                                 // display old values and values that push to old queue using new queue;

    myQueue<int> s2(size);                        
                                                  // make new queue;
    if (s2.isEmpty())
    {
        for (int i = 0; i < n-k ; i++)            // n-k value ko new queue ma push;
        {
            s2.enqueue(obj.peek());               
            obj.dequeue();
        }
    }
   // s2.display();                                // n-k values in new s2 queue;

    cout << "\n Reversing K values in Queue";
    while (!s2.isEmpty())
    {
        obj.enqueue(s2.peek());                 // push back to old obj queue;
        s2.dequeue();
    }
    obj.display();


    return 0;
}


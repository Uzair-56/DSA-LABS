#include "myQueue.h"

int main()
{
    int size;
    cout << "Enter size of Printer Document:\n";
    cin >> size;

    myQueue<string>obj(size);


    string id;
    cout << "Enter Print Document Name:";
    for (int i = 0; i < size; i++)
    {
        cin >> id;
        obj.enqueue(id);
    }

       obj.display();

        cout << "Dequeued the Document at the Front:"<<obj.dequeue();
        obj.display();
        
        cout <<"Document on Front:"<<obj.peek()<<endl;
        obj.display();

        cout << "Print All The Document In Queue. ";
        obj.display();

         return 0;
}
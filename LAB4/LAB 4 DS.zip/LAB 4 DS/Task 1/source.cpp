#include "myQueue.h"
#include<iostream>
using namespace std;
int main()
{
    int size = 0;
    cout << "Enter the size of Queue";
    cin >> size;
    myQueue<int> obj(size);

    int value;
    for (int i = 0; i < size; i++)
    {
        cout << "Enter Value" << i + 1 << ":";
        cin >> value;

        obj.enqueue(value);
    }

    cout << "Peek: " << obj.peek() << endl;
    obj.display();

    cout << "Dequeued value:" << obj.dequeue();

    cout << endl << endl;

    return 0;
}

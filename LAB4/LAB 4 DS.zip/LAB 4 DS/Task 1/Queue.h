#pragma once
template<class T>
class Queue
{
protected:

    T* arr;
    int currentSize;
    int maxSize;

public:
    virtual void enqueue(T v) = 0;
    virtual T dequeue() = 0;

    virtual T peek() = 0;

    virtual bool isEmpty() = 0;
    virtual bool isFull() = 0;

    Queue(int size);
    ~Queue();

};

template<class T>
Queue<T>::Queue(int size)
{
    maxSize = size;
    currentSize = 0;
    arr = new T[size];
}

template<class T>
Queue<T>::~Queue()
{
    delete[]arr;
}

#include "myQueue.h"

int main()
{
    int size;
    cout << "Enter size of TicketId:\n";
    cin >> size;
    myQueue<int> obj(size);


    int id;
    cout << "Enter ID's Of Ticket:";
    for (int i = 0; i < size; i++)
    {
        cin >> id;

        if (id < 1000 || id > 9999)
        {
            cout << "Invalid TicketId.";
            cout << endl;
        }

        else
        {
            myQueue<int>s1(size);

            bool duplicate = false;

            while (!obj.isEmpty())
            {
                int value = obj.peek();

                if (value == id)
                {
                    duplicate = true;
                }
                    s1.enqueue(value);
                    obj.dequeue();
                
            }

            while (!s1.isEmpty())
            {
                obj.enqueue(s1.peek());
                s1.dequeue();
            }

            if (duplicate)
            {
                cout << "This Id is Duplicate." << endl;
            }
            else
            {
                obj.enqueue(id);
                cout << "Ticket added Successfully." << endl;
            }
        }
    }
        obj.display();

        cout <<"\nResolve(remove) the Tickt:"<< obj.dequeue()<<endl;
        obj.display();
        


        cout <<"Ticket on Front:"<<obj.peek()<<endl;
        obj.display();

         return 0;
}
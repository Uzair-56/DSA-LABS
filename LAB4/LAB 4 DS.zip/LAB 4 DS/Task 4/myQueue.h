#pragma once

#include "Queue.h"

template<class T>
class myQueue :public Queue<T> 
{
 
public:

    void enqueue(T v);
    myQueue(int);
    void display();
    T dequeue();
    bool isEmpty();
    bool isFull();

    T peek();
};

template<class T>
T myQueue<T>::peek() //O(1)
{
    if (isEmpty())
    {
        cout << "Queue is Empty, returning JUNK zero" << endl;
        return 0;
    }

    else
    {
        return this->arr[0];
    }

}

template<class T>
bool myQueue<T>::isFull() //O(1)
{
    return (this->currentSize == this->maxSize);
}

template<class T>
bool myQueue<T>::isEmpty()  //O(1)
{
    return (this->currentSize == 0);
}

template<class T>
T myQueue<T>::dequeue() //O(N)
{
    if (isEmpty())
    {
        cout << "Queue is Empty, returning JUNK zero" << endl;
        return 0;
    }
    else
    {
        T retValue = this->arr[0];

        this->currentSize--;

        for (int i = 0; i < this->currentSize; i++)
            this->arr[i] = this->arr[i + 1];

        return retValue;
    }

}

template<class T>   //O(1)
myQueue<T>::myQueue(int s) :Queue<T>(s)
{

}

template<class T> //O(1)
void myQueue<T>::enqueue(T v)
{
    if (!isFull())
    {
        this->arr[Queue<T>::currentSize] = v;
        this->currentSize++;
    }

    else
        cout << "Queue is full" << endl;

}

template<class T>
void myQueue<T>::display()      //O(N)
{
    cout << "\n-----------------------------\n";
  //  cout << "Max Size = " << this->maxSize << endl;
    //cout << "Current Size = " << Queue<T>::currentSize << endl;
  
    for (int i = 0; i < Queue<T>::currentSize; i++)
        cout << i << ". " << this->arr[i] << endl;
}